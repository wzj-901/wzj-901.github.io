// ==UserScript==
// @version      2
// @description  北京大学选课系统验证码智能识别
// @match        *://course.pku.edu.cn/*
// ==/UserScript==

(function() {
    'use strict';

    // 核心权重配置
    const CORE_WEIGHTS = {
        1: 1.9,  // 核心1：通用型
        2: 0.65,  // 核心2：
        3: 0.9,  // 核心3：备用核
        4: 0.95,  // 核心4：最高权重
        5: 0.98   // 核心5：新版模型
    };

    // 初始化参数
    const hrf = window.location.href;
    let useCore = null;

    // 解析URL参数
    if (hrf.includes('course.pku.edu.cn')) {
        const urlParams = new URLSearchParams(window.location.search);
        const coreParam = urlParams.get('core');
        
        if (coreParam && /^[1-5]$/.test(coreParam)) {
            useCore = parseInt(coreParam, 10);
            console.log(`[模式] 强制使用 Core ${useCore}`);
        }
    }

    // 主逻辑
    window.onload = function() {
        if (!document.querySelector('img[src="/webapps/bb-sso-BBLEARN/execute/authValidate/getCaptcha"]')) return;

        // TensorFlow 加载器
        const loadTF = async () => {
            return new Promise((resolve, reject) => {
                if (window.tf) return resolve();

                const script = document.createElement('script');
                script.src = 'https://cdn.jsdelivr.net/npm/@tensorflow/tfjs@4.22.0/dist/tf.min.js';
                script.onload = () => resolve();
                script.onerror = reject;
                document.head.appendChild(script);
            });
        };

        // 验证码处理器
        const processCaptcha = async (captchaImg, coreNumber) => {
            try {
                // 加载模型
                const model = await tf.loadLayersModel(
                    `https://wzj-901.github.io/Tensorflow/train-${coreNumber}.json`,
                    {
                        weightUrlConverter: () => `https://wzj-901.github.io/Tensorflow/train-${coreNumber}.bin`
                    }
                );

                // 预处理图像
                const canvas = document.createElement('canvas');
                const ctx = canvas.getContext('2d');
                [canvas.width, canvas.height] = [60, 20];
                ctx.drawImage(captchaImg, 0, 0, 60, 20);

                // 切片处理
                const slices = Array.from({length: 4}, (_, i) => {
                    const sliceCanvas = document.createElement('canvas');
                    [sliceCanvas.width, sliceCanvas.height] = [15, 20];
                    sliceCanvas.getContext('2d').drawImage(
                        canvas, i * 15, 0, 15, 20, 0, 0, 15, 20
                    );
                    return sliceCanvas;
                });

                // 模型预测
                const prediction = await tf.tidy(() => {
                    const input = tf.stack(slices.map(c => 
                        tf.browser.fromPixels(c)
                            .transpose([1, 0, 2])
                            .toFloat()
                            .div(255)
                            .neg()
                            .add(1)
                    ));
                    return model.predict(input).argMax(1).dataSync();
                });

                // 清理资源
                canvas.remove();
                slices.forEach(c => c.remove());
                tf.dispose(model);

                return Array.from(prediction).join('');
            } catch (error) {
                console.error(`[Core ${coreNumber}] 处理失败:`, error);
                return null;
            }
        };

        // 混合模式决策
        const hybridDecision = async (captchaImg) => {
            const cores = [1, 2, 3, 4, 5];
            const results = {};

            // 并行处理
            await Promise.all(cores.map(async core => {
                results[core] = await processCaptcha(captchaImg, core);
                console.log(`[Core ${core}] 结果: ${results[core]}`);
            }));

            // 权重投票
            const scoreMap = {};
            Object.entries(results).forEach(([core, value]) => {
                if (!value) return;
                const weight = CORE_WEIGHTS[core];
                scoreMap[value] = (scoreMap[value] || 0) + weight;
            });

            // 最佳结果
            const [finalResult] = Object.entries(scoreMap)
                .sort((a, b) => b[1] - a[1])
                .map(e => e[0]);

            return finalResult || '';
        };

        // 执行入口
        const main = async () => {
            await loadTF();
            const captchaImg = document.querySelector('img[src="/webapps/bb-sso-BBLEARN/execute/authValidate/getCaptcha"]');
            const inputField = document.getElementById('captcha');

            if (useCore) {
                // 单核模式
                const result = await processCaptcha(captchaImg, useCore);
                inputField.value = result || '';
                console.log(`[最终结果] ${result}`);
            } else {
                // 混合模式
                const result = await hybridDecision(captchaImg);
                inputField.value = result;
                console.log(`[混合决策] ${result}`);
            }

            // 自动提交（可选）
            // document.querySelector('form').submit();
        };

        main().catch(console.error);
    };
})();
